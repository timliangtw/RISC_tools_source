#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <time.h>
#include <fcntl.h>
#include <linux/input.h>
#include <string.h>
#include <signal.h>

#define TEST_PASS 0
#define TEST_FAIL -1

int getBoardName(char* ret_string)
{
	FILE *pp;
	char tmp[20];

	if ((pp = popen("cat /proc/board", "r")) == NULL)
	{
		printf("\n [getBoardName] popen() error!\n");
		return TEST_FAIL;
	}
	if (fgets(tmp, 12, pp))
	{
		pclose(pp);
		strncpy(ret_string, tmp, strlen(tmp));
		return TEST_PASS;
	} else {
		pclose(pp);
		return TEST_FAIL;
	}
}

int getLinuxBase()
{
	FILE *pp;
	char tmp[80];

	if ((pp = popen("cat /etc/issue |grep Yocto", "r")) == NULL)
	{
		printf("\n [getLinuxBase] popen() error!\n");
		return TEST_FAIL;
	}
	if (fgets(tmp, 80, pp)) //Yocto
	{
		pclose(pp);
		return TEST_PASS;
	} 
	else //Ltib 
	{
		pclose(pp);
		return TEST_FAIL;
	}
}

int main(void)
{
	int key_state;
	int fd;
	int ret;
	int code;
	char start,poweroff_flag;
 	int i,count, count_1, count_2;
	struct timeval tpstart,tpend; 
	int timesec, time_usec;
	int timesec_stop,timesec_start,time_usec_stop,time_usec_start;
	struct input_event buf;
	char cmd[64];
	char start_count;
	char board[20];

	if((getLinuxBase() == TEST_PASS) && (getBoardName(board) == TEST_PASS) && (strstr(board, "ROM-3420") != NULL))
		fd = open("/dev/input/event1", O_RDONLY); //Yocto and ROM-3420 with keypad function
	else
		fd = open("/dev/input/event0", O_RDONLY);

	if (fd < 0) {
     		printf("[%s] Open gpio-keys failed.\n", board);
     		return -1;
   	} else
     		printf("[%s] Open gpio-keys success.\n", board);

	start_count = 0;
 	while(1) {
 		ret = read(fd,&buf,sizeof(struct input_event));
     		if(ret <= 0) {
       			printf("read fail!\n");
       			return -1;
     		}
     		code = buf.code;
 		key_state = buf.value;
 		switch(code) {
			case KEY_SUSPEND:
         			if(key_state) {
					gettimeofday(&tpstart,NULL); 
					//printf("\n----start  time----\n") ; 
 					start_count=1;
				} else {
					if(start_count) {
						//printf("\n----check time----\n") ; 
						gettimeofday(&tpend,NULL); 
						time_usec_start= tpstart.tv_usec/100000;
						time_usec_stop= tpend.tv_usec/100000;
						timesec_start = time_usec_start + tpstart.tv_sec*10;
						timesec_stop  = time_usec_stop  + tpend.tv_sec*10;
						//timesec = tpend.tv_sec-tpstart.tv_sec;
						//time_usec = tpend.tv_usec-tpstart.tv_usec;
						timesec = timesec_stop - timesec_start ;
						printf("\n---- time_diff [%ld]- start[%ld] stop[%ld] ----\n",timesec,timesec_start,timesec_stop);
           					if((timesec > 10)&&(timesec < 40)) {
							printf("\n-------------------------  poweroff  ----------------------\n");
							sprintf(cmd, "poweroff");
							system(cmd);
           					}
            					start_count=0;
					}	
				}
        		break;
        		default:
				code = 0;
        		break;
		}

	}
	close(fd);
	return 0;
}

