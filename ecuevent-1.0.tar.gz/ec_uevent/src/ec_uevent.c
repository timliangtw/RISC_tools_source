#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/poll.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <linux/types.h>
#include <linux/netlink.h>


void substr(char *dest, const char* src, unsigned int start, unsigned int cnt) 
{
	strncpy(dest, src + start, cnt);
	dest[cnt] = 0;
}

int main(int argc, char *argv[])
{
	struct sockaddr_nl nls;
	struct pollfd pfd;
    	char buf[512], cmd[64];
    	char t[16], s[3];
    	char t1[16]="CAPACIT";
    	char t2[16]="PRESENT";
    	int  present_value=0, capacity_value=0;
    	char PRESENT_flag=0;
    	memset(&nls, 0, sizeof(nls));
    	nls.nl_family = AF_NETLINK;
    	nls.nl_pid = getpid();
    	nls.nl_groups = -1;

    	pfd.events = POLLIN;
    	pfd.fd = socket(PF_NETLINK, SOCK_DGRAM, NETLINK_KOBJECT_UEVENT);
    	if (pfd.fd == -1) {
        	printf("Not root\n");
        	exit(1);
    	}

    	if (bind(pfd.fd, (void*)&nls, sizeof(nls))) {
        	printf("bind failed\n");
        	exit(1);
    	}
	while (-1 != poll(&pfd, 1, -1)) {
        	int i, len = recv(pfd.fd, buf, sizeof(buf), MSG_DONTWAIT);
        	if (len == -1) {
            		printf("recv\n");
            		exit(1);
        	}
        	i = 0;
        
        	while (i < len) {
           	substr(t, buf + i, 13, 7);
           	if(!strcmp(t,t2)) { 
             		substr(s, buf + i, 21, 1);
             		present_value = atoi(s);
              		if(present_value) {
              			//printf("PRESENT_flag=1 [%s] \n ",t);
              			PRESENT_flag=1;
              		} else {
              			//printf("PRESENT_flag=0 \n ");
              			PRESENT_flag=0;
              		}
           	}
          
           	if(PRESENT_flag) {
            		if(!strcmp(t,t1)) {
             			substr(s, buf + i, 22, 3);
             			capacity_value = atoi(s);
             			//printf(" %s==>%d \n ",t,capacity_value);
             			if(capacity_value < 10) {
              				printf("-------capacity=%s[%d] \n ",s,capacity_value);
              				printf("\n-------------------------  poweroff  ----------------------\n");
              				sprintf(cmd, "poweroff");
              				system(cmd);
             			}
            		}
           	}
         	i += strlen(buf+i) + 1;
        	}
    	}
    	printf("\n");
    	return 0;
}
