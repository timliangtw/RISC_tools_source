#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <time.h>
#include <fcntl.h>
#include <linux/input.h>
#include <string.h>
#include <signal.h>

#define TEST_PASS 0
#define TEST_FAIL -1

int getBoardName(char* ret_string)
{
	FILE *pp;
	char tmp[20];

	if ((pp = popen("cat /proc/board", "r")) == NULL)
	{
		printf("\n [getBoardName] popen() error!\n");
		return TEST_FAIL;
	}
	if (fgets(tmp, 12, pp))
	{
		pclose(pp);
		strncpy(ret_string, tmp, strlen(tmp));
		return TEST_PASS;
	} else {
		pclose(pp);
		return TEST_FAIL;
	}
}

int getLinuxBase()
{
	FILE *pp;
	char tmp[80];

	if ((pp = popen("cat /etc/issue |grep Distro", "r")) == NULL)
	{
		printf("\n [getLinuxBase] popen() error!\n");
		return TEST_FAIL;
	}
	if (fgets(tmp, 80, pp)) //Yocto
	{
		pclose(pp);
		return TEST_PASS;
	} 
	else //Ltib 
	{
		pclose(pp);
		return TEST_FAIL;
	}
}

int main(void)
{
	int key_state;
	int fd;
	int ret;
	int type, code;
	struct input_event buf;
	char cmd[64];
	int start_count;
	char board[20];
	int suspend_flag=0;
	int poweroff_flag=0;

	if((getLinuxBase() == TEST_PASS) && (getBoardName(board) == TEST_PASS) && (strstr(board, "ROM-3420") != NULL))
		fd = open("/dev/input/event1", O_RDONLY); //Yocto and ROM-3420 with keypad function
	else
		fd = open("/dev/input/event0", O_RDONLY);

	if (fd < 0) {
     		printf("[%s] Open gpio-keys failed.\n", board);
     		return -1;
   	} else
     		printf("[%s] Open gpio-keys success.\n", board);

 	while(1) {
 		ret = read(fd,&buf,sizeof(struct input_event));
     		if(ret <= 0) {
       			printf("read fail!\n");
       			return -1;
     		}
		type = buf.type;
     		code = buf.code;
 		key_state = buf.value;

		//printf("\n*** [key_event] type:%d; code:%d, key_state:%d\n", type,code,key_state);

 		switch(code) {
			case KEY_SUSPEND:
				if(!suspend_flag) { /* sleep mode */
					if(key_state) {
 						start_count=1;
					} else {
						if(start_count) {
							printf("\n-------------------------  suspend  ----------------------\n");
							suspend_flag = 1;
							sprintf(cmd, "echo mem > /sys/power/state");
							system(cmd);
							start_count=0;
						}	
					}
				} else { /* wake up mode */
					if(!key_state)
						suspend_flag = 0;
				}
				break;
			case KEY_POWER:
				if(!poweroff_flag) {
					if(!key_state) {
						printf("\n-------------------------  poweroff  ----------------------\n");
						poweroff_flag = 1;
						sprintf(cmd, "poweroff");
						system(cmd);
					}
				}
        			break;
			default:
				code = 0;
				break;
		}

	}
	close(fd);
	return 0;
}

